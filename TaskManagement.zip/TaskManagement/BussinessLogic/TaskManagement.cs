﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data.Entity.Core.Objects;


namespace BussinessLogic
{
    public class TaskManagement
    {
        TaskManagementEntities entities = null;

        public int InsertTask(Tbl_Task task)
        {
            try
            {
                entities = new TaskManagementEntities();
                int i = 0;
                entities.sp_InsertTask(task.Title, task.Description, task.DueDate, task.RequiredHours, task.Priority, new ObjectParameter("tid", i));
                return i;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally 
            {
                entities.Dispose();
            }

        }

        public int UpdateTask(Tbl_Task task)
        {
            try
            {
                entities = new TaskManagementEntities();
                int i = 0;
                entities.sp_updateTask(task.Title, task.Description, task.DueDate, task.RequiredHours, task.Priority,task.TId, new ObjectParameter("upid", i));
                return i;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                entities.Dispose();
            }
        }

        public int DeleteTask(int Tid)
        {
            try
            {
                entities = new TaskManagementEntities();
                int i = 0;
                entities.sp_delTask(Tid, new ObjectParameter("erid", i));
                return i;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                entities.Dispose();
            }
        }

        public List<sp_SelectTask_Result> GetTask(string searchby = "")
        {
            try
            {
                entities = new TaskManagementEntities();
                List<sp_SelectTask_Result> searchresult = entities.sp_SelectTask(searchby).ToList();
                return searchresult;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                entities.Dispose();
            }
        }

    }
}
