﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Helpers;

namespace SimpleTaskManagement.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(BussinessLogic.Tbl_Task tbltask)
        {
            try
            {

                BussinessLogic.TaskManagement tm = new BussinessLogic.TaskManagement();
                int i = tm.InsertTask(tbltask);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return View();
        }

        public ActionResult GetTask(string searchby = "")
        {
            try
            {
                BussinessLogic.TaskManagement tm = new BussinessLogic.TaskManagement();
                List<BussinessLogic.sp_SelectTask_Result> gtask = tm.GetTask(searchby);
                return PartialView("SearchTask", gtask);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ActionResult UpdateTask(string title, string description, string duedate, string requiredhours, string priority, string TId)
        {
            try
            {

                BussinessLogic.TaskManagement tm = new BussinessLogic.TaskManagement();
                BussinessLogic.Tbl_Task tblupdate = new BussinessLogic.Tbl_Task();
                tblupdate.Title = title;
                tblupdate.Description = description;
                tblupdate.DueDate = Convert.ToDateTime(duedate);
                tblupdate.RequiredHours = Convert.ToInt32(requiredhours);
                tblupdate.Priority = Convert.ToInt32(priority);
                tblupdate.TId = Convert.ToInt32(TId);
                int i = tm.UpdateTask(tblupdate);
                return RedirectToAction("GetTask");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ActionResult DeleteTask(int id)
        {
            try
            {

                BussinessLogic.TaskManagement tm = new BussinessLogic.TaskManagement();
                int i = tm.DeleteTask(id);
                return RedirectToAction("GetTask");
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public ActionResult DrawTask(string searchby = "")
        {
            try
            {
                BussinessLogic.TaskManagement tm = new BussinessLogic.TaskManagement();
                List<BussinessLogic.sp_SelectTask_Result> gtask = tm.GetTask(searchby);
                string[] title =  new string[gtask.Count];
                string[] hours =  new string[gtask.Count];
                for (int i = 0; i < gtask.Count; i++)
                {
                    title[i] = gtask[i].Title;
                    hours[i] = gtask[i].RequiredHours.ToString();
                }
                //return PartialView("SearchTask", gtask);
                var chart = new Chart(width: 200, height: 200)
                .AddSeries(
                            chartType: "bar",
                            xValue: title,
                            yValues: hours)
                            .GetBytes("png");
                return File(chart, "image/bytes");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
